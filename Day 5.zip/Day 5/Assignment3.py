lst = ["hi","i","am","prakhar","how","are","you"]
temp = list(map(lambda ele: ele.capitalize(), lst))
temp = str(temp)
print(temp)
